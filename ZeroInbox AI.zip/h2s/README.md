# 🚀 ZeroInbox AI – Email That Thinks For You

A hackathon-ready demo application that uses AI to intelligently categorize, summarize, and suggest actions for emails, helping users achieve inbox zero with one-click actions.

## ✨ Features

- **AI-Powered Email Analysis**: Automatically categorizes emails (Urgent, Action Required, Info, Promo)
- **Smart Summaries**: 2-line AI-generated summaries for quick understanding
- **One-Click Actions**: Handle emails with suggested actions (Reply Yes, Ask for info, Handle later)
- **Inbox Gravity Meter**: Visual progress tracker that decreases as you handle emails
- **Bulk Cleanup**: Clear promotional emails with one click
- **Before/After Toggle**: See the difference AI makes
- **Beautiful UI**: Modern, clean interface designed for demos

## 🛠️ Tech Stack

- **Frontend**: React + Vite
- **Backend**: Node.js + Express
- **AI**: OpenAI GPT-3.5-turbo (with mock fallback)
- **Styling**: Pure CSS with modern gradients

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ installed
- (Optional) OpenAI API key for real AI processing

### Installation

1. **Install all dependencies:**
   ```bash
   npm run install:all
   ```

2. **Set up environment variables (optional):**
   ```bash
   cd backend
   cp .env.example .env
   # Edit .env and add your OPENAI_API_KEY
   ```

   > **Note**: The app works without an API key using smart mock AI responses!

3. **Start the development servers:**
   ```bash
   npm run dev
   ```

   This starts:
   - Frontend on `http://localhost:3000`
   - Backend on `http://localhost:3001`

4. **Open your browser:**
   Navigate to `http://localhost:3000`

## 📖 How It Works

1. **Email Inbox**: View 15 diverse mock emails (interviews, deadlines, newsletters, etc.)
2. **AI Processing**: Click an email to trigger AI analysis (categorization, summary, action suggestion)
3. **Take Action**: Use one-click buttons to handle emails
4. **Watch Gravity Drop**: See your inbox gravity score decrease as you clear emails
5. **Bulk Cleanup**: Use "Clear Promotional Emails" to remove multiple emails at once

## 🎯 Demo Flow (2 Minutes)

1. **Show the problem**: Toggle "Before AI" to see a cluttered inbox
2. **Click an email**: Show AI analyzing and categorizing
3. **Take action**: Click "Reply Yes" or another action button
4. **Show progress**: Point out gravity meter decreasing
5. **Bulk cleanup**: Click "Clear Promotional Emails"
6. **Celebrate**: Show "Zero Gravity Achieved 🚀" message

## 🏆 Why This Wins

- ✅ **Clear problem**: Everyone struggles with email overload
- ✅ **AI actually helps**: Real categorization and summaries
- ✅ **Antigravity theme**: Visual progress that judges remember
- ✅ **Smooth demo**: Works perfectly without real email integration
- ✅ **Easy to explain**: Simple concept, powerful execution

## 📁 Project Structure

```
zeroinbox-ai/
├── frontend/
│   ├── src/
│   │   ├── App.jsx       # Main application component
│   │   ├── App.css       # Styling
│   │   ├── main.jsx      # React entry point
│   │   └── index.css     # Global styles
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── backend/
│   ├── data/
│   │   └── emails.json   # Mock email data
│   ├── server.js         # Express server + AI logic
│   └── package.json
├── package.json          # Root package.json
└── README.md
```

## 🔧 API Endpoints

- `GET /api/emails` - Get all unhandled emails
- `GET /api/emails/:id` - Get single email
- `POST /api/process-email` - Process email with AI
- `POST /api/emails/:id/handle` - Handle an email (mark as done)
- `POST /api/bulk-cleanup` - Bulk clean promotional emails
- `POST /api/reset` - Reset all emails (for demo)

## 🎨 Customization

### Adding More Emails

Edit `backend/data/emails.json` to add more mock emails.

### Changing AI Behavior

Modify the prompt in `backend/server.js` in the `/api/process-email` endpoint.

### Styling

All styles are in `frontend/src/App.css`. The design uses:
- Gradient backgrounds
- Modern color palette
- Smooth transitions
- Responsive layout

## 🐛 Troubleshooting

**Port already in use?**
- Change ports in `frontend/vite.config.js` and `backend/server.js`

**AI not working?**
- Check if `OPENAI_API_KEY` is set in `backend/.env`
- The app works with mock AI if no key is provided

**Emails not loading?**
- Make sure backend is running on port 3001
- Check browser console for errors

## 📝 Notes

- This is a **demo/hackathon project**, not production-ready
- No real email integration (uses mock data)
- No authentication required
- Perfect for showcasing AI capabilities

## 🚀 Next Steps

- Add real Gmail integration
- Implement email sending
- Add user authentication
- Deploy to production

---

**Built for hackathons. Built to win. 🏆**

