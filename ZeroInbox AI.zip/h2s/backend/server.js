import express from 'express';
import cors from 'cors';
import { readFileSync, writeFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import OpenAI from 'openai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3001;

// Initialize OpenAI (fallback to mock if no API key)
const openai = process.env.OPENAI_API_KEY 
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

// Load emails
function loadEmails() {
  const filePath = join(__dirname, 'data', 'emails.json');
  const data = readFileSync(filePath, 'utf-8');
  return JSON.parse(data);
}

function saveEmails(emails) {
  const filePath = join(__dirname, 'data', 'emails.json');
  writeFileSync(filePath, JSON.stringify(emails, null, 2));
}

// Mock AI response (for demo if no OpenAI key)
function getMockAIResponse(email) {
  const subject = email.subject.toLowerCase();
  const body = email.body.toLowerCase();
  
  let category = 'Info';
  let summary = 'General information email.';
  let suggestedAction = 'Read and archive';
  
  if (subject.includes('urgent') || subject.includes('deadline') || body.includes('end of day') || body.includes('asap')) {
    category = 'Urgent';
    summary = 'Time-sensitive action required.';
    suggestedAction = 'Reply immediately';
  } else if (subject.includes('interview') || subject.includes('meeting') || subject.includes('appointment')) {
    category = 'Action Required';
    summary = 'Requires your response or confirmation.';
    suggestedAction = 'Reply Yes';
  } else if (subject.includes('newsletter') || subject.includes('promo') || subject.includes('offer') || 
             subject.includes('discount') || email.sender.toLowerCase().includes('netflix') || 
             email.sender.toLowerCase().includes('spotify') || email.sender.toLowerCase().includes('starbucks') ||
             email.sender.toLowerCase().includes('uber')) {
    category = 'Promo';
    summary = 'Promotional or marketing content.';
    suggestedAction = 'Archive';
  } else if (subject.includes('security') || subject.includes('alert') || subject.includes('unusual')) {
    category = 'Urgent';
    summary = 'Security-related notification.';
    suggestedAction = 'Review and verify';
  } else if (subject.includes('assignment') || subject.includes('due') || subject.includes('deadline')) {
    category = 'Action Required';
    summary = 'Academic or work deadline approaching.';
    suggestedAction = 'Complete task';
  }
  
  return { category, summary, suggestedAction };
}

// AI processing endpoint
app.post('/api/process-email', async (req, res) => {
  try {
    const { emailId } = req.body;
    const emails = loadEmails();
    const email = emails.find(e => e.id === emailId);
    
    if (!email) {
      return res.status(404).json({ error: 'Email not found' });
    }
    
    // If already processed, return cached result
    if (email.category && email.summary) {
      return res.json({
        category: email.category,
        summary: email.summary,
        suggestedAction: email.suggestedAction
      });
    }
    
    let result;
    
    if (openai) {
      // Use real OpenAI API
      const prompt = `Analyze this email and provide:
1. Category (one of: Urgent, Action Required, Info, Promo)
2. A 2-line summary
3. A suggested action (one short phrase)

Email Subject: ${email.subject}
Email Body: ${email.body}

Respond in JSON format: {"category": "...", "summary": "...", "suggestedAction": "..."}`;

      const completion = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are an email assistant that categorizes and summarizes emails. Always respond with valid JSON." },
          { role: "user", content: prompt }
        ],
        temperature: 0.3,
      });
      
      const content = completion.choices[0].message.content;
      result = JSON.parse(content);
    } else {
      // Use mock AI
      result = getMockAIResponse(email);
    }
    
    // Update email with AI results
    email.category = result.category;
    email.summary = result.summary;
    email.suggestedAction = result.suggestedAction;
    saveEmails(emails);
    
    res.json(result);
  } catch (error) {
    console.error('Error processing email:', error);
    res.status(500).json({ error: 'Failed to process email' });
  }
});

// Get all emails
app.get('/api/emails', (req, res) => {
  try {
    const emails = loadEmails();
    res.json(emails.filter(e => !e.handled));
  } catch (error) {
    console.error('Error loading emails:', error);
    res.status(500).json({ error: 'Failed to load emails' });
  }
});

// Get single email
app.get('/api/emails/:id', (req, res) => {
  try {
    const emails = loadEmails();
    const email = emails.find(e => e.id === req.params.id);
    if (!email) {
      return res.status(404).json({ error: 'Email not found' });
    }
    res.json(email);
  } catch (error) {
    console.error('Error loading email:', error);
    res.status(500).json({ error: 'Failed to load email' });
  }
});

// Handle email action
app.post('/api/emails/:id/handle', (req, res) => {
  try {
    const { action } = req.body;
    const emails = loadEmails();
    const email = emails.find(e => e.id === req.params.id);
    
    if (!email) {
      return res.status(404).json({ error: 'Email not found' });
    }
    
    email.handled = true;
    email.handledAction = action;
    saveEmails(emails);
    
    res.json({ success: true, message: 'Email handled successfully ✨' });
  } catch (error) {
    console.error('Error handling email:', error);
    res.status(500).json({ error: 'Failed to handle email' });
  }
});

// Bulk cleanup promotional emails
app.post('/api/bulk-cleanup', async (req, res) => {
  try {
    const emails = loadEmails();
    let cleaned = 0;
    
    // Process all unhandled emails to identify promos
    for (const email of emails) {
      if (!email.handled && !email.category) {
        const result = openai ? await processWithAI(email) : getMockAIResponse(email);
        email.category = result.category;
        email.summary = result.summary;
        email.suggestedAction = result.suggestedAction;
      }
      
      if (!email.handled && email.category === 'Promo') {
        email.handled = true;
        email.handledAction = 'Bulk Archive';
        cleaned++;
      }
    }
    
    saveEmails(emails);
    res.json({ success: true, cleaned, message: `Cleaned ${cleaned} promotional emails ✨` });
  } catch (error) {
    console.error('Error bulk cleaning:', error);
    res.status(500).json({ error: 'Failed to bulk clean' });
  }
});

async function processWithAI(email) {
  if (!openai) return getMockAIResponse(email);
  
  const prompt = `Analyze this email and provide:
1. Category (one of: Urgent, Action Required, Info, Promo)
2. A 2-line summary
3. A suggested action (one short phrase)

Email Subject: ${email.subject}
Email Body: ${email.body}

Respond in JSON format: {"category": "...", "summary": "...", "suggestedAction": "..."}`;

  const completion = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      { role: "system", content: "You are an email assistant that categorizes and summarizes emails. Always respond with valid JSON." },
      { role: "user", content: prompt }
    ],
    temperature: 0.3,
  });
  
  const content = completion.choices[0].message.content;
  return JSON.parse(content);
}

// Reset emails (for demo purposes)
app.post('/api/reset', (req, res) => {
  try {
    const emails = loadEmails();
    emails.forEach(email => {
      email.handled = false;
      email.handledAction = null;
    });
    saveEmails(emails);
    res.json({ success: true });
  } catch (error) {
    console.error('Error resetting:', error);
    res.status(500).json({ error: 'Failed to reset' });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 ZeroInbox AI Backend running on http://localhost:${PORT}`);
  if (!openai) {
    console.log('⚠️  No OpenAI API key found. Using mock AI responses.');
    console.log('   Set OPENAI_API_KEY in .env for real AI processing.');
  }
});

