import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

const API_BASE = '/api';

function App() {
  const [emails, setEmails] = useState([]);
  const [selectedEmail, setSelectedEmail] = useState(null);
  const [loading, setLoading] = useState(false);
  const [gravityScore, setGravityScore] = useState(100);
  const [showBefore, setShowBefore] = useState(false);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    loadEmails();
  }, []);

  useEffect(() => {
    // Calculate gravity score based on handled emails
    const totalEmails = 15; // Total emails in system
    const handledCount = totalEmails - emails.length;
    const newScore = Math.max(0, 100 - (handledCount * (100 / totalEmails)));
    setGravityScore(Math.round(newScore));
  }, [emails]);

  const loadEmails = async () => {
    try {
      const response = await axios.get(`${API_BASE}/emails`);
      setEmails(response.data);
      if (response.data.length > 0 && !selectedEmail) {
        setSelectedEmail(response.data[0]);
      }
    } catch (error) {
      console.error('Error loading emails:', error);
    }
  };

  const handleEmailClick = async (email) => {
    setSelectedEmail(email);
    setMessage(null);
    
    // Process email with AI if not already processed
    if (!email.category || !email.summary) {
      setLoading(true);
      try {
        const response = await axios.post(`${API_BASE}/process-email`, {
          emailId: email.id
        });
        
        // Update email in local state
        setEmails(prev => prev.map(e => 
          e.id === email.id 
            ? { ...e, ...response.data }
            : e
        ));
        
        setSelectedEmail({ ...email, ...response.data });
      } catch (error) {
        console.error('Error processing email:', error);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleAction = async (action) => {
    if (!selectedEmail) return;
    
    setLoading(true);
    try {
      await axios.post(`${API_BASE}/emails/${selectedEmail.id}/handle`, {
        action
      });
      
      setMessage('Email handled successfully ✨');
      
      // Remove email from list
      setTimeout(() => {
        setEmails(prev => prev.filter(e => e.id !== selectedEmail.id));
        const remaining = emails.filter(e => e.id !== selectedEmail.id);
        if (remaining.length > 0) {
          setSelectedEmail(remaining[0]);
        } else {
          setSelectedEmail(null);
        }
        setMessage(null);
      }, 1000);
    } catch (error) {
      console.error('Error handling email:', error);
      setMessage('Error handling email');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkCleanup = async () => {
    setLoading(true);
    try {
      const response = await axios.post(`${API_BASE}/bulk-cleanup`);
      setMessage(response.data.message);
      await loadEmails();
      setTimeout(() => setMessage(null), 2000);
    } catch (error) {
      console.error('Error bulk cleaning:', error);
      setMessage('Error cleaning emails');
    } finally {
      setLoading(false);
    }
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'Urgent':
        return '#ef4444';
      case 'Action Required':
        return '#f59e0b';
      case 'Info':
        return '#3b82f6';
      case 'Promo':
        return '#10b981';
      default:
        return '#6b7280';
    }
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    return date.toLocaleDateString();
  };

  // Show "before" state (all 15 emails)
  const displayEmails = showBefore ? Array(15).fill(null).map((_, i) => ({
    id: `before-${i}`,
    sender: 'Email Sender',
    subject: 'Sample Email Subject',
    timestamp: new Date().toISOString(),
    category: null
  })) : emails;

  return (
    <div className="app">
      <header className="header">
        <div className="header-content">
          <h1>🚀 ZeroInbox AI</h1>
          <p className="tagline">Email That Thinks For You</p>
        </div>
        <div className="header-controls">
          <div className="toggle-container">
            <label className="toggle-label">
              <input
                type="checkbox"
                checked={showBefore}
                onChange={(e) => setShowBefore(e.target.checked)}
              />
              <span>Before AI</span>
            </label>
          </div>
          <button 
            className="bulk-cleanup-btn"
            onClick={handleBulkCleanup}
            disabled={loading || emails.length === 0}
          >
            Clear Promotional Emails
          </button>
        </div>
      </header>

      <div className="main-container">
        <div className="sidebar">
          <div className="gravity-meter">
            <div className="gravity-header">
              <h2>Inbox Gravity</h2>
              <span className="gravity-score">{gravityScore}%</span>
            </div>
            <div className="gravity-bar-container">
              <div 
                className="gravity-bar"
                style={{ width: `${gravityScore}%` }}
              />
            </div>
            {gravityScore === 0 && (
              <div className="zero-gravity-message">
                Zero Gravity Achieved 🚀
              </div>
            )}
          </div>

          <div className="email-list">
            <h3 className="email-list-header">
              Inbox ({displayEmails.length})
            </h3>
            {displayEmails.length === 0 ? (
              <div className="empty-inbox">
                <p>🎉 Inbox Zero Achieved!</p>
                <p className="empty-subtitle">All emails handled</p>
              </div>
            ) : (
              displayEmails.map((email) => (
                <div
                  key={email.id}
                  className={`email-item ${
                    selectedEmail?.id === email.id ? 'selected' : ''
                  }`}
                  onClick={() => handleEmailClick(email)}
                >
                  <div className="email-item-header">
                    <span className="email-sender">{email.sender}</span>
                    {email.category && (
                      <span
                        className="email-category-badge"
                        style={{ backgroundColor: getCategoryColor(email.category) }}
                      >
                        {email.category}
                      </span>
                    )}
                  </div>
                  <div className="email-subject">{email.subject}</div>
                  <div className="email-time">{formatDate(email.timestamp)}</div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="email-viewer">
          {selectedEmail ? (
            <div className="email-content">
              {message && (
                <div className="success-message">{message}</div>
              )}
              
              <div className="email-header">
                <h2>{selectedEmail.subject}</h2>
                <div className="email-meta">
                  <div className="email-meta-item">
                    <strong>From:</strong> {selectedEmail.sender}
                  </div>
                  <div className="email-meta-item">
                    <strong>Date:</strong> {formatDate(selectedEmail.timestamp)}
                  </div>
                </div>
              </div>

              {loading && !selectedEmail.category && (
                <div className="ai-loading">
                  <div className="spinner"></div>
                  <p>AI is analyzing this email...</p>
                </div>
              )}

              {selectedEmail.category && (
                <div className="ai-analysis">
                  <div className="ai-header">
                    <span className="ai-icon">🤖</span>
                    <h3>AI Analysis</h3>
                  </div>
                  
                  <div className="ai-category">
                    <span
                      className="category-badge-large"
                      style={{ backgroundColor: getCategoryColor(selectedEmail.category) }}
                    >
                      {selectedEmail.category}
                    </span>
                  </div>

                  <div className="ai-summary-box">
                    <h4>Summary</h4>
                    <p>{selectedEmail.summary}</p>
                  </div>

                  {selectedEmail.category === 'Urgent' && (
                    <div className="urgency-indicator">
                      ⚠️ Deadline: Today
                    </div>
                  )}

                  <div className="ai-suggestion">
                    <h4>Suggested Action</h4>
                    <p>{selectedEmail.suggestedAction}</p>
                  </div>
                </div>
              )}

              <div className="email-body">
                <h4>Email Content</h4>
                <div className="email-text">{selectedEmail.body}</div>
              </div>

              {selectedEmail.category && !selectedEmail.handled && (
                <div className="action-buttons">
                  <button
                    className="action-btn primary"
                    onClick={() => handleAction('Reply Yes')}
                    disabled={loading}
                  >
                    ✓ Reply Yes
                  </button>
                  <button
                    className="action-btn secondary"
                    onClick={() => handleAction('Ask for more info')}
                    disabled={loading}
                  >
                    ? Ask for more info
                  </button>
                  <button
                    className="action-btn tertiary"
                    onClick={() => handleAction('Handle later')}
                    disabled={loading}
                  >
                    ⏰ Handle later
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="no-email-selected">
              <p>Select an email to view</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;

